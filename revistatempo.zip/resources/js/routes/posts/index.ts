import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\NoticiaController::search
 * @see app/Http/Controllers/NoticiaController.php:203
 * @route '/posts/search'
 */
export const search = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

search.definition = {
    methods: ["get","head"],
    url: '/posts/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NoticiaController::search
 * @see app/Http/Controllers/NoticiaController.php:203
 * @route '/posts/search'
 */
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NoticiaController::search
 * @see app/Http/Controllers/NoticiaController.php:203
 * @route '/posts/search'
 */
search.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NoticiaController::search
 * @see app/Http/Controllers/NoticiaController.php:203
 * @route '/posts/search'
 */
search.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NoticiaController::search
 * @see app/Http/Controllers/NoticiaController.php:203
 * @route '/posts/search'
 */
    const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: search.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NoticiaController::search
 * @see app/Http/Controllers/NoticiaController.php:203
 * @route '/posts/search'
 */
        searchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: search.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NoticiaController::search
 * @see app/Http/Controllers/NoticiaController.php:203
 * @route '/posts/search'
 */
        searchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: search.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    search.form = searchForm
/**
* @see \App\Http\Controllers\NoticiaController::show
 * @see app/Http/Controllers/NoticiaController.php:68
 * @route '/posts/{slug}'
 */
export const show = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/posts/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NoticiaController::show
 * @see app/Http/Controllers/NoticiaController.php:68
 * @route '/posts/{slug}'
 */
show.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return show.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NoticiaController::show
 * @see app/Http/Controllers/NoticiaController.php:68
 * @route '/posts/{slug}'
 */
show.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NoticiaController::show
 * @see app/Http/Controllers/NoticiaController.php:68
 * @route '/posts/{slug}'
 */
show.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NoticiaController::show
 * @see app/Http/Controllers/NoticiaController.php:68
 * @route '/posts/{slug}'
 */
    const showForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NoticiaController::show
 * @see app/Http/Controllers/NoticiaController.php:68
 * @route '/posts/{slug}'
 */
        showForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NoticiaController::show
 * @see app/Http/Controllers/NoticiaController.php:68
 * @route '/posts/{slug}'
 */
        showForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\NoticiaController::byCategory
 * @see app/Http/Controllers/NoticiaController.php:177
 * @route '/categoria/{slug}'
 */
export const byCategory = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byCategory.url(args, options),
    method: 'get',
})

byCategory.definition = {
    methods: ["get","head"],
    url: '/categoria/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NoticiaController::byCategory
 * @see app/Http/Controllers/NoticiaController.php:177
 * @route '/categoria/{slug}'
 */
byCategory.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return byCategory.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NoticiaController::byCategory
 * @see app/Http/Controllers/NoticiaController.php:177
 * @route '/categoria/{slug}'
 */
byCategory.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byCategory.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NoticiaController::byCategory
 * @see app/Http/Controllers/NoticiaController.php:177
 * @route '/categoria/{slug}'
 */
byCategory.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: byCategory.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NoticiaController::byCategory
 * @see app/Http/Controllers/NoticiaController.php:177
 * @route '/categoria/{slug}'
 */
    const byCategoryForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: byCategory.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NoticiaController::byCategory
 * @see app/Http/Controllers/NoticiaController.php:177
 * @route '/categoria/{slug}'
 */
        byCategoryForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: byCategory.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NoticiaController::byCategory
 * @see app/Http/Controllers/NoticiaController.php:177
 * @route '/categoria/{slug}'
 */
        byCategoryForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: byCategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    byCategory.form = byCategoryForm
const posts = {
    search: Object.assign(search, search),
show: Object.assign(show, show),
byCategory: Object.assign(byCategory, byCategory),
}

export default posts
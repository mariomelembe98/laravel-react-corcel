import category from './category'
import posts from './posts'
const api = {
    category: Object.assign(category, category),
posts: Object.assign(posts, posts),
}

export default api
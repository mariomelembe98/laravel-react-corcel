import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\NoticiaController::suggestions
 * @see app/Http/Controllers/NoticiaController.php:238
 * @route '/api/posts/suggestions'
 */
export const suggestions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: suggestions.url(options),
    method: 'get',
})

suggestions.definition = {
    methods: ["get","head"],
    url: '/api/posts/suggestions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NoticiaController::suggestions
 * @see app/Http/Controllers/NoticiaController.php:238
 * @route '/api/posts/suggestions'
 */
suggestions.url = (options?: RouteQueryOptions) => {
    return suggestions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NoticiaController::suggestions
 * @see app/Http/Controllers/NoticiaController.php:238
 * @route '/api/posts/suggestions'
 */
suggestions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: suggestions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NoticiaController::suggestions
 * @see app/Http/Controllers/NoticiaController.php:238
 * @route '/api/posts/suggestions'
 */
suggestions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: suggestions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NoticiaController::suggestions
 * @see app/Http/Controllers/NoticiaController.php:238
 * @route '/api/posts/suggestions'
 */
    const suggestionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: suggestions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NoticiaController::suggestions
 * @see app/Http/Controllers/NoticiaController.php:238
 * @route '/api/posts/suggestions'
 */
        suggestionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: suggestions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NoticiaController::suggestions
 * @see app/Http/Controllers/NoticiaController.php:238
 * @route '/api/posts/suggestions'
 */
        suggestionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: suggestions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    suggestions.form = suggestionsForm
const posts = {
    suggestions: Object.assign(suggestions, suggestions),
}

export default posts
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\NoticiaController::preview
 * @see app/Http/Controllers/NoticiaController.php:264
 * @route '/api/categories/{slug}/preview'
 */
export const preview = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/api/categories/{slug}/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NoticiaController::preview
 * @see app/Http/Controllers/NoticiaController.php:264
 * @route '/api/categories/{slug}/preview'
 */
preview.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return preview.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NoticiaController::preview
 * @see app/Http/Controllers/NoticiaController.php:264
 * @route '/api/categories/{slug}/preview'
 */
preview.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NoticiaController::preview
 * @see app/Http/Controllers/NoticiaController.php:264
 * @route '/api/categories/{slug}/preview'
 */
preview.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NoticiaController::preview
 * @see app/Http/Controllers/NoticiaController.php:264
 * @route '/api/categories/{slug}/preview'
 */
    const previewForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: preview.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NoticiaController::preview
 * @see app/Http/Controllers/NoticiaController.php:264
 * @route '/api/categories/{slug}/preview'
 */
        previewForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NoticiaController::preview
 * @see app/Http/Controllers/NoticiaController.php:264
 * @route '/api/categories/{slug}/preview'
 */
        previewForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    preview.form = previewForm
const category = {
    preview: Object.assign(preview, preview),
}

export default category
import Auth from './Auth'
import NoticiaController from './NoticiaController'
import ComentarioController from './ComentarioController'
import Settings from './Settings'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
NoticiaController: Object.assign(NoticiaController, NoticiaController),
ComentarioController: Object.assign(ComentarioController, ComentarioController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers